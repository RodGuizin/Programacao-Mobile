package android.guilhermerodrigues.etimpamiiloginmvc.controller;

import java.util.List;

public interface iCrud<T> {
    public boolean inserir(T obj);
    public boolean alterar(T obj);
    public boolean excluir(int id);
    public boolean buscar(int id);
    public List<T> listar();
}
