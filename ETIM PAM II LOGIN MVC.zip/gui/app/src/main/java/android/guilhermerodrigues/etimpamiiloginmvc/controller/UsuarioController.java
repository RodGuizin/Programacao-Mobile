package android.guilhermerodrigues.etimpamiiloginmvc.controller;


import android.content.Context;
import android.guilhermerodrigues.etimpamiiloginmvc.datasource.AppDataBase;

import java.util.Collections;
import java.util.List;

public class UsuarioController extends AppDataBase implements iCrud {

    public UsuarioController(Context context){
        super(context);
    }

    @Override
    public boolean inserir(Object obj) {
        return false;
    }

    @Override
    public boolean alterar(Object obj) {
        return false;
    }

    @Override
    public boolean excluir(int id) {
        return false;
    }

    @Override
    public boolean buscar(int id) {
        return false;
    }

    @Override
    public List listar() {
        return Collections.emptyList();
    }
}

