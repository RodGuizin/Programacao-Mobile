package android.guilhermerodrigues.etimpamiiloginmvc.model;

public class Usuario {
}
